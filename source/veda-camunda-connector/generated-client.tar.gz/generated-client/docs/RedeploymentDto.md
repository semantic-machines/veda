# RedeploymentDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_ids** | Option<**Vec<String>**> | A list of deployment resource ids to re-deploy. | [optional]
**resource_names** | Option<**Vec<String>**> | A list of deployment resource names to re-deploy. | [optional]
**source** | Option<**String**> | Sets the source of the deployment. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


