# LinkableDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | Option<[**Vec<crate::models::AtomLink>**](AtomLink.md)> | The links associated to this resource, with `method`, `href` and `rel`. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


