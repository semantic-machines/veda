# PriorityDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**priority** | Option<**i64**> | The priority of the resource. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


