# UserProfileDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> | The id of the user. | [optional]
**first_name** | Option<**String**> | The first name of the user. | [optional]
**last_name** | Option<**String**> | The first name of the user. | [optional]
**email** | Option<**String**> | The email of the user. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


