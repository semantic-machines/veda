# ParseExceptionDtoAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**details** | Option<[**::std::collections::HashMap<String, crate::models::ResourceReportDto>**](ResourceReportDto.md)> | A JSON Object containing list of errors and warnings occurred during deployment. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


