# MetricsResultDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | Option<**i64**> | The current sum (count) for the selected metric. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


