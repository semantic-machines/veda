# UserCredentialsDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**password** | Option<**String**> | The users new password. | [optional]
**authenticated_user_password** | Option<**String**> | The password of the authenticated user who changes the password of the user (i.e., the user with passed id as path parameter). | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


