# DeploymentResourceDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> | The id of the deployment resource. | [optional]
**name** | Option<**String**> | The name of the deployment resource | [optional]
**deployment_id** | Option<**String**> | The id of the deployment. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


