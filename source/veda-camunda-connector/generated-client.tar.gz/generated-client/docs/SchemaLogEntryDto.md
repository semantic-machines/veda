# SchemaLogEntryDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> | The id of the schema log entry. | [optional]
**timestamp** | Option<**String**> | The date and time of the schema update. | [optional]
**version** | Option<**String**> | The version of the schema. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


