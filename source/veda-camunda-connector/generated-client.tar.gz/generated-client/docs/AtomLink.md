# AtomLink

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rel** | Option<**String**> | The relation of the link to the object that belongs to. | [optional]
**href** | Option<**String**> | The url of the link. | [optional]
**method** | Option<**String**> | The http method. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


