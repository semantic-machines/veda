# ExternalTaskBpmnErrorAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**worker_id** | Option<**String**> | The id of the worker that reports the failure. Must match the id of the worker who has most recently locked the task. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


