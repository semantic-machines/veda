# SortTaskQueryParametersDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**variable** | Option<**String**> | The name of the variable to sort by. | [optional]
**_type** | Option<**String**> | The name of the type of the variable value. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


