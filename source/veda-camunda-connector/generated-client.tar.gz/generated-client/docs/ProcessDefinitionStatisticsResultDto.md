# ProcessDefinitionStatisticsResultDto

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> | The id of the process definition the results are aggregated for. | [optional]
**instances** | Option<**i32**> | The total number of running process instances of this process definition. | [optional]
**failed_jobs** | Option<**i32**> | The total number of failed jobs for the running instances. **Note**: Will be `0` (not `null`), if failed jobs were excluded. | [optional]
**incidents** | Option<[**Vec<crate::models::IncidentStatisticsResultDto>**](IncidentStatisticsResultDto.md)> | Each item in the resulting array is an object which contains `incidentType` and `incidentCount`. **Note**: Will be an empty array, if `incidents` or `incidentsForType` were excluded. Furthermore, the array will be also empty if no incidents were found. | [optional]
**definition** | Option<[**crate::models::ProcessDefinitionDto**](ProcessDefinitionDto.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


